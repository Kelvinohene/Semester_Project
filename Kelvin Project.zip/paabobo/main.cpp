#include <iostream>
#include <string>
#include <vector>
#include <fstream>
#include <cstdlib>
#include <cctype>
using namespace std;

struct User {
    string username;
    string passwordHash;
};

vector<User> users;

string hashPassword(const string& password) {
    return password + "hashed";
}

bool usernameExists(const string& username) {
    for (size_t i = 0; i < users.size(); ++i) {
        if (users[i].username == username) {
            return true;
        }
    }
    return false;
}

bool isStrongPassword(const string& password) {
    if (password.length() < 8) {
        return false;
    }

    bool hasDigit = false;
    bool hasUppercase = false;

    for (size_t i = 0; i < password.length(); ++i) {
        if (isdigit(password[i])) {
            hasDigit = true;
        } else if (isupper(password[i])) {
            hasUppercase = true;
        }
    }

    return hasDigit && hasUppercase;
}

void registerUser() {
    User newUser;
    cout << "Enter username: ";
    cin >> newUser.username;

    if (usernameExists(newUser.username)) {
        cout << "Username already exists." << endl;
        return;
    }

    string password;
    while (true) {
        cout << "Enter password: ";
        cin >> password;

        if (isStrongPassword(password)) {
            break;
        } else {
            cout << "Password is not strong enough." << endl;
        }
    }

    newUser.passwordHash = hashPassword(password);
    users.push_back(newUser);

    cout << "Registration successful!" << endl;
}

void loginUser() {
    string username, password;
    cout << "Enter username: ";
    cin >> username;

    for (size_t i = 0; i < users.size(); ++i) {
        if (users[i].username == username) {
            cout << "Enter password: ";
            cin >> password;

            string hashedInputPassword = hashPassword(password);
            if (users[i].passwordHash == hashedInputPassword) {
                cout << "Login successful!" << endl;
                return;
            } else {
                cout << "Incorrect password." << endl;
                return;
            }
        }
    }
    
    cout << "User not found." << endl;
}

void changePassword() {
    string username, newPassword;
    cout << "Enter username: ";
    cin >> username;

    for (size_t i = 0; i < users.size(); ++i) {
        if (users[i].username == username) {
            cout << "Enter new password: ";
            cin >> newPassword;

            if (isStrongPassword(newPassword)) {
                users[i].passwordHash = hashPassword(newPassword);
                cout << "Password changed successfully!" << endl;
            } else {
                cout << "Password is not strong enough." << endl;
            }

            return;
        }
    }
    
    cout << "User not found." << endl;
}

void deleteUser() {
    string username;
    cout << "Enter username to delete: ";
    cin >> username;

    for (size_t i = 0; i < users.size(); ++i) {
        if (users[i].username == username) {
            users.erase(users.begin() + i);
            cout << "User '" << username << "' deleted successfully!" << endl;
            return;
        }
    }
    
    cout << "User not found." << endl;
}

void listUsers() {
    cout << "Registered Users:" << endl;
    for (size_t i = 0; i < users.size(); ++i) {
        cout << "Username: " << users[i].username << endl;
    }
}

int main() {
    int choice;
    char inputChar;
    
    while (true) {
        cout << "Welcome to the Registration System" << endl;
        cout << "1. Register" << endl;
        cout << "2. Login" << endl;
        cout << "3. Change Password" << endl;
        cout << "4. Delete Account" << endl;
        cout << "5. List Users" << endl;
        cout << "6. Exit" << endl;
        cout << "Enter your choice: ";
        cin >> inputChar;
        if(isalpha(inputChar)){
        	cout<<"Invalid input"<<endl;
        	break;
		}
		choice = inputChar - '0';

        switch (choice) {
            case 1:
                registerUser();
                break;
            case 2:
                loginUser();
                break;
            case 3:
                changePassword();
                break;
            case 4:
                deleteUser();
                break;
            case 5:
                listUsers();
                break;
            case 6:
                cout << "Goodbye!" << endl;
                return 0;
            default:
                cout << "Invalid choice." << endl;
                break;
        }
    }
}
